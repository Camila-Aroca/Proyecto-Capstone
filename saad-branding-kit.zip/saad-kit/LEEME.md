# SAAD · Kit de identidad visual

- `saad-tokens.css` / `saad-tokens.json`: tokens (colores, tipografía, radios, sombras, espaciado, movimiento, dataviz).
- `icons/mono` (currentColor), `icons/duotone`, `icons/saad-sprite.svg`, `icons/icons.json`: 17 íconos SVG.
- `shapes`, `accents`, `patterns`, `illustrations`: recursos de marca en SVG.
Fuentes: Plus Jakarta Sans (titulares, KPI) e Inter (texto, datos), de Google Fonts.
Uso: cambio visual sobre la plataforma existente; no modifica layout ni funciones.
